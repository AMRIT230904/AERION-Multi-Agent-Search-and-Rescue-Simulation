# AERION - Multi-Agent Drone Navigation in Project AirSim  

## Overview

This project focuses on autonomous drone navigation using Reinforcement Learning (RL) in Microsoft Project AirSim integrated with Unreal Engine 5.

The current implementation includes:

- Single-agent drone navigation using Deep Reinforcement Learning
- LiDAR-based obstacle avoidance
- Goal-directed autonomous flight
- DQN, PPO, and TD3 implementations
- Unreal Engine urban simulation environment
- Project AirSim integration

The project is being extended toward a Multi-Agent Reinforcement Learning (MARL) framework where multiple drones operate simultaneously in a shared environment.

---

## Project Goal

Develop a scalable multi-drone autonomous navigation system capable of:

- Coordinated exploration
- Collision avoidance
- Cooperative path planning
- Distributed decision making
- Multi-agent reinforcement learning

Applications include:

- Search and Rescue
- Disaster Monitoring
- Smart City Surveillance
- Infrastructure Inspection
- Autonomous Delivery Systems

---

## Current Architecture

### Simulation Environment

- Unreal Engine 5
- Project AirSim
- Urban Sparse Environment

### Sensors

Each drone is equipped with:

- LiDAR Sensor
- IMU
- GPS
- Barometer
- Magnetometer
- Downward Camera

### Observation Space

Each agent receives:

- 36 LiDAR sectors
- Relative Goal Position
- Distance to Goal

Observation Vector: `[36 LiDAR sectors, relative_x, relative_y, relative_z, distance_to_goal]` (39 values).

### Task Allocation

A lightweight hierarchical coordinator (`coordinator.py`) sits above the per-drone
policies:

- Each drone's own DQN/PPO/TD3 policy still decides step-to-step velocity
  commands independently (decentralized execution).
- The coordinator's only job is centralized task allocation: given N idle
  drones and M pending tasks/goals, it solves a min-cost assignment
  (Hungarian algorithm via SciPy, with an automatic greedy fallback if SciPy
  isn't installed) and hands each drone a goal.
- `tasks/` owns the mission's task pool (`Task`, `TaskManager`, `Prioritizer`)
  — priority, status (`PENDING` / `ASSIGNED` / `IN_PROGRESS` / `COMPLETE` /
  `FAILED`), and reassignment when an agent drops out mid-mission.

---

## Repository Structure

```
AERION/
├── coordinator.py            # Hierarchical task/goal allocator (Hungarian matching)
├── multi_agent_train.py      # Decentralized multi-drone training loop (Independent Q-Learning)
├── multi_drone_hover.py      # Minimal multi-drone hover demo over pynng
├── train_sandbox.py          # Single-agent DQN training entry point
├── aerion_ros2_node.py       # ROS2 node wrapper around the AERION stack
├── ros2_goal_listener.py     # ROS2 node that listens for incoming goal poses
├── tasks/                    # Task pool: Task, TaskManager, Prioritizer
├── sim_config/                # Project AirSim scene/robot configs (.jsonc)
├── tests/                    # pytest test suite
├── requirements.txt           # Core pip dependencies
├── requirements-dev.txt       # + pytest, for running the test suite
└── pytest.ini
```

---

## Installation

1. **Python dependencies** (Python 3.10+ recommended):

   ```bash
   pip install -r requirements.txt
   ```

2. **Simulation stack** (only needed to actually fly drones, not to run the
   task-allocation unit tests):
   - [Microsoft Project AirSim](https://github.com/microsoft/projectairsim) — install
     per its own setup instructions; it isn't distributed on PyPI.
   - Unreal Engine 5 with an AirSim-compatible environment (e.g. the Urban
     Sparse sample environment).
   - ROS2 (e.g. Humble) if you're using `aerion_ros2_node.py` /
     `ros2_goal_listener.py` — `rclpy` ships with the ROS2 distro, not pip.

## Usage

```bash
# Single-agent training (DQN, LiDAR-based obstacle avoidance)
python train_sandbox.py

# Multi-agent training (independent Q-learning + centralized task allocation)
python multi_agent_train.py

# Minimal multi-drone hover demo
python multi_drone_hover.py

# Sanity-check the task allocator in isolation, no simulator required
python coordinator.py
```

## Testing

```bash
pip install -r requirements-dev.txt
pytest
```

The task-allocation and task-pool tests (`tests/test_task*.py`,
`tests/test_coordinator.py`, `tests/test_failure_recovery.py`) run without a
simulator. `tests/test_sandbox.py` exercises the training loop and needs the
full `requirements.txt` set installed.

---

## Roadmap

- [ ] Inter-drone collision avoidance (beyond each agent's own LiDAR)
- [ ] Centralized-training/decentralized-execution MARL (e.g. QMIX) as an
      alternative to Independent Q-Learning
- [ ] Batched/async AirSim client so per-step latency doesn't grow linearly
      with agent count

## License

[MIT](LICENSE)
